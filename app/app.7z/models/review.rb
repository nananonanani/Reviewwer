class Review < ApplicationRecord
  belongs_to :user
end
