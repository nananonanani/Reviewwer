class UsersController < ApplicationController
  def index
  end

  def create
    @user = User.new(user_params)
    @user.save
    render "index"
  end

  def new
    @user = User.new
  end

  private
    def user_params
      params.require(:user).permit(:login_id, :name, :password, :password_confirmation)
    end
end
