class ReviewsController < ApplicationController
  def new
    @review = Review.new
  end

  def index
    
  end

  def create
    @review = Review.new(review_params)
    @review.user_id = session[:user_id]
    if @review.valid?
      logger.debug("valid")
      @review.save
    else
      logger.debug("invalid")
      logger.debug(@review.errors.messages)
    end
    render "index"
  end

  private
  def review_params
    params.require(:review).permit(:content, :star)
  end
end
